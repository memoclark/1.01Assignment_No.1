package com.derama.semifinal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static final String FILE_NAME = "info.txt";

    private EditText ETName, ETAddress, ETAge, ETBirthday, ETMobile;
    private Spinner SPNGender;
    private Button BTNSave, BTNLoad;

    private FileOutputStream fileOutputStream;
    private FileInputStream fileInputStream;
    private InputStreamReader inputStreamReader;
    private BufferedReader bufferedReader;

    private ArrayList<String> strings = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Instantiate  Widgets
        ETName = findViewById(R.id.edittext_name);
        ETAddress = findViewById(R.id.edittext_address);
        ETAge = findViewById(R.id.edittext_age);
        ETBirthday = findViewById(R.id.edittext_birthday);
        ETMobile = findViewById(R.id.edittext_mobilenumber);
        SPNGender = findViewById(R.id.spinner_gender);
        BTNSave = findViewById(R.id.button_save);
        BTNLoad = findViewById(R.id.button_load);

        //Populate Spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.genders_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        SPNGender.setAdapter(adapter);

        //OnClick for Buttons
        BTNSave.setOnClickListener(v -> {
            if (SomeFieldsAreMissing()) {
                Toast.makeText(getBaseContext(), "Some fields are missing!", Toast.LENGTH_SHORT).show();
            } else {
                String text = "";
                text = ETName.getText().toString().trim();
                text += "|" + ETAddress.getText().toString().trim();
                text += "|" + ETAge.getText().toString().trim();
                text += "|" + ETBirthday.getText().toString().trim();
                text += "|" + ETMobile.getText().toString().trim();
                text += "|" + SPNGender.getSelectedItem().toString();

                ETName.getText().clear();
                ETAddress.getText().clear();
                ETAge.getText().clear();
                ETBirthday.getText().clear();
                ETMobile.getText().clear();

                fileOutputStream = null;
                try {
                    fileOutputStream = openFileOutput(FILE_NAME, MODE_PRIVATE);
                    fileOutputStream.write(text.getBytes());
                    Toast.makeText(getBaseContext(), "Saved to " + getFilesDir() + FILE_NAME, Toast.LENGTH_SHORT).show();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (fileOutputStream != null) {
                        try {
                            fileOutputStream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });

        BTNLoad.setOnClickListener(v -> {
            fileInputStream = null;
            try {
                fileInputStream = openFileInput(FILE_NAME);
                inputStreamReader = new InputStreamReader(fileInputStream);
                bufferedReader = new BufferedReader(inputStreamReader);
                String text = "";
                text = bufferedReader.readLine();
                String[] readStrings = text.split("\\|");

                ETName.setText(readStrings[0]);
                ETAddress.setText(readStrings[1]);
                ETAge.setText(readStrings[2]);
                ETBirthday.setText(readStrings[3]);
                ETMobile.setText(readStrings[4]);
                switch (readStrings[5]) {
                    case "Male":
                        SPNGender.setSelection(0);
                        break;
                    case "Female":
                        SPNGender.setSelection(1);
                        break;
                }

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (fileInputStream != null) {
                    try {
                        fileInputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    private boolean SomeFieldsAreMissing() {
        return (TextUtils.isEmpty(ETName.getText().toString())
                || TextUtils.isEmpty(ETAddress.getText().toString())
                || TextUtils.isEmpty(ETAge.getText().toString())
                || TextUtils.isEmpty(ETBirthday.getText().toString())
                || TextUtils.isEmpty(ETMobile.getText().toString())
        );
    }
}